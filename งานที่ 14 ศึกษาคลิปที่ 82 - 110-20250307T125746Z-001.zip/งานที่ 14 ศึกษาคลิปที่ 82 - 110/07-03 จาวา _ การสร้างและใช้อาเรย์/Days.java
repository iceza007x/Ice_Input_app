import jlab.graphics.DWindow;
import java.util.Scanner;

public class Days {
    public static void main(String[] args) {
        
        String[] daysOfWeek = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        
        
        System.out.println("The first day of the week is: " + daysOfWeek[0]);  
        System.out.println("The last day of the week is: " + daysOfWeek[6]);   
        
        
        System.out.println("The days of the week are:");
        for (int i = 0; i < daysOfWeek.length; i++) {
            System.out.println(daysOfWeek[i]);
        }
        
        
        daysOfWeek[0] = "New Monday";  
        System.out.println("Updated first day of the week: " + daysOfWeek[0]);
    }
}

