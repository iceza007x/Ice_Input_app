package ArrayUtil;

import jlab.graphics.DWindow;
import java.util.Scanner;

public class ArrayUtil {
    public static void main(String[] args) {
        
        int[] c = new int[10];  

        
        for (int i = 0; i < c.length; i++) {
            c[i] = i * 2;  
        }

        
        printArray(c);
    }

    
    public static void printArray(int[] arr) {
        System.out.println("Array elements:");
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[i]);  
        }
    }
}

    

