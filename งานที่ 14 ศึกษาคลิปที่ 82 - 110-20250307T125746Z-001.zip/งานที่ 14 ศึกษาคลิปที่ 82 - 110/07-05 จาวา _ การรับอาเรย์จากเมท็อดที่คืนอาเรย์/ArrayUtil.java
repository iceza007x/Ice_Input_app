import jlab.graphics.DWindow;
import java.util.Scanner;

public class ArrayUtil {
    public static void main(String[] args) {
        int[] originalArray = {1, 2, 3, 4, 5};
        int[] newArray = modifyArray(originalArray);

        for (int i = 0; i < newArray.length; i++) {
            System.out.println(newArray[i]);
        }
    }

    public static int[] modifyArray(int[] arr) {
        int[] modifiedArray = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            modifiedArray[i] = arr[i] * 2;
        }
        return modifiedArray;
    }
}
