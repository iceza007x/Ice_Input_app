import java.awt.*;
import javax.swing.*;

public class LineGraph extends JPanel {
    private int[] values;

    public LineGraph(int[] values) {
        this.values = values;
    }

    
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLUE);
        
        
        int width = getWidth();
        int height = getHeight();
        
        
        int spacing = width / values.length;
        
        for (int i = 0; i < values.length; i++) {
            
            int x = i * spacing;
            int y = height - values[i]; 
            g.fillRect(x, y, spacing - 2, values[i]);
        }
    }

    public static void main(String[] args) {
        
        int[] data = {50, 20, 80, 40, 60, 30, 70, 90, 10, 100};

        
        LineGraph(data);

        
        JFrame frame = new JFrame("Selection Sort Graph");
        LineGraph graph = new LineGraph(data);
        frame.add(graph);
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    public static void LineGraph(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            // Swap the found minimum element with the first element
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }
    }
}
