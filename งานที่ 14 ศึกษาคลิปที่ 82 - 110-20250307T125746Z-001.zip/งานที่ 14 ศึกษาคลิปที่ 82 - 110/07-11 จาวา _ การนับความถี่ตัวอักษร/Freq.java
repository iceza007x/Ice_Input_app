import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;

public class Freq {
    public static void main(String[] args) {
        String input = "hello world"; 
        Map frequencyMap = new HashMap();

        
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (frequencyMap.containsKey(new Character(c))) {
                Integer count = (Integer) frequencyMap.get(new Character(c));
                frequencyMap.put(new Character(c), new Integer(count.intValue() + 1));
            } else {
                frequencyMap.put(new Character(c), new Integer(1));
            }
        }

        
        Iterator iterator = frequencyMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry entry = (Map.Entry) iterator.next();
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }
    }
}
