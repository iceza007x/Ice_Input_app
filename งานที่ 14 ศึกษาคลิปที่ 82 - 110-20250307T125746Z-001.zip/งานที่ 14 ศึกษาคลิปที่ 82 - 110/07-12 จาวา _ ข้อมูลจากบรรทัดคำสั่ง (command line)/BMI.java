public class BMI {
    public static void main(String[] args) {
        // Check if both weight and height are provided
        if (args.length != 2) {
            System.out.println("Please provide both weight and height.");
            System.out.println("Usage: java BMI <weight> <height>");
            return;
        }

        try {
            // Get weight and height from command-line arguments
            double weight = Double.parseDouble(args[0]);
            double height = Double.parseDouble(args[1]);

            // Calculate BMI
            double bmi = weight / (height * height);

            // Display the BMI result
            System.out.println("Your BMI is: " + bmi);

            // Categorize the BMI
            if (bmi < 18.5) {
                System.out.println("Underweight");
            } else if (bmi >= 18.5 && bmi < 24.9) {
                System.out.println("Normal weight");
            } else if (bmi >= 25 && bmi < 29.9) {
                System.out.println("Overweight");
            } else {
                System.out.println("Obese");
            }
        } catch (NumberFormatException e) {
            // Handle the case where input is not a valid number
            System.out.println("Please enter valid numbers for weight and height.");
        }
    }
}
