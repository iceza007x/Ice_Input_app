import jlab.graphics.DWindow;
import java.util.Scanner;

public class MatrixAddition {
    public static void main(String[] args) {
        // Define two 2x3 matrices
        int[][] matrixA = {
            {1, 2, 3},
            {4, 5, 6}
        };

        int[][] matrixB = {
            {6, 5, 4},
            {3, 2, 1}
        };

        // Check if the matrices have the same dimensions
        if (matrixA.length != matrixB.length || matrixA[0].length != matrixB[0].length) {
            System.out.println("Matrix dimensions must be the same for addition.");
            return;
        }

        // Create a matrix to store the result
        int[][] result = new int[matrixA.length][matrixA[0].length];

        // Perform matrix addition
        for (int i = 0; i < matrixA.length; i++) {
            for (int j = 0; j < matrixA[i].length; j++) {
                result[i][j] = matrixA[i][j] + matrixB[i][j];
            }
        }

        // Print the result matrix
        System.out.println("Result of Matrix Addition:");
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < result[i].length; j++) {
                System.out.print(result[i][j] + " ");
            }
            System.out.println();
        }
    }
}
