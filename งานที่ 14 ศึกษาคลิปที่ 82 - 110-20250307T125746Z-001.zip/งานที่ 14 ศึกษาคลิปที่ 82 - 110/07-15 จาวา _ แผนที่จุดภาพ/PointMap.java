import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class PointMap extends JPanel {
    private BufferedImage image;
    private int[][] points;

    public PointMap(BufferedImage image, int[][] points) {
        this.image = image;
        this.points = points;
    }

    
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        
        g.drawImage(image, 0, 0, null);

        
        g.setColor(Color.RED);

        
        for (int i = 0; i < points.length; i++) {
            int x = points[i][0];
            int y = points[i][1];
            g.fillOval(x - 5, y - 5, 10, 10); 
        }
    }

    public static void main(String[] args) {
        try {
            
            File imageFile = new File("C:/Users/Hp/Pictures/Screenshots/hey.png");  
            BufferedImage image = ImageIO.read(imageFile);

            
            int[][] points = {
                {50, 50},
                {150, 100},
                {250, 200},
                {350, 300}
            };

            
            JFrame frame = new JFrame("Point Map");
            PointMap pointMap = new PointMap(image, points);
            frame.add(pointMap);
            frame.setSize(400, 400);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setVisible(true);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading the image.");
        }
    }
}
