import java.util.Arrays;

public class ArraysExample {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};
        int[] copiedArray = Arrays.copyOf(numbers, 7); // ???? 7
        System.out.println(Arrays.toString(copiedArray));
    }
}
