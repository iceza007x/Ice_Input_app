import javax.swing.*;
import java.awt.*;
import java.util.Random;

public class BallCollision extends JPanel {
    private Ball[] balls;

    public BallCollision(int numBalls) {
        balls = new Ball[numBalls];
        for (int i = 0; i < numBalls; i++) {
            balls[i] = new Ball();
        }
    }

    public void update() {
        // ????????????????????????????
        for (int i = 0; i < balls.length; i++) {
            balls[i].move(getWidth(), getHeight());
        }

        // ?????????????????????????
        for (int i = 0; i < balls.length; i++) {
            for (int j = i + 1; j < balls.length; j++) {
                if (balls[i].collidesWith(balls[j])) {
                    balls[i].bounceOff(balls[j]);
                }
            }
        }
    }

   
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        // ????????????????
        for (int i = 0; i < balls.length; i++) {
            balls[i].draw(g);
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ball Collision");
        BallCollision panel = new BallCollision(5);
        frame.add(panel);
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        while (true) {
            panel.update();
            panel.repaint();
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class Ball {
    private int x, y, dx, dy, radius;
    private static final int MAX_SPEED = 5;
    private Random random;

    public Ball() {
        random = new Random();
        this.x = random.nextInt(400) + 100;
        this.y = random.nextInt(400) + 100;
        this.radius = 20;
        this.dx = random.nextInt(MAX_SPEED * 2 + 1) - MAX_SPEED;
        this.dy = random.nextInt(MAX_SPEED * 2 + 1) - MAX_SPEED;
    }

    public void move(int width, int height) {
        x += dx;
        y += dy;

        // ????????????
        if (x - radius < 0 || x + radius > width) {
            dx = -dx;
        }
        if (y - radius < 0 || y + radius > height) {
            dy = -dy;
        }
    }

    public void draw(Graphics g) {
        g.setColor(Color.RED);
        g.fillOval(x - radius, y - radius, radius * 2, radius * 2);
    }

    public boolean collidesWith(Ball other) {
        int dx = this.x - other.x;
        int dy = this.y - other.y;
        int distance = (int) Math.sqrt(dx * dx + dy * dy);
        return distance < this.radius + other.radius;
    }

    public void bounceOff(Ball other) {
        int tempDx = this.dx;
        int tempDy = this.dy;
        this.dx = other.dx;
        this.dy = other.dy;
        other.dx = tempDx;
        other.dy = tempDy;
    }
}
