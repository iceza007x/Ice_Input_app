import jlab.graphics.DWindow;
import java.util.Scanner;

public class TestComplex {
    static class Complex {
        private double real;
        private double imaginary;

        public Complex(double real, double imaginary) {
            this.real = real;
            this.imaginary = imaginary;
        }

        public Complex add(Complex other) {
            double realPart = this.real + other.real;
            double imaginaryPart = this.imaginary + other.imaginary;
            return new Complex(realPart, imaginaryPart);
        }

        public Complex subtract(Complex other) {
            double realPart = this.real - other.real;
            double imaginaryPart = this.imaginary - other.imaginary;
            return new Complex(realPart, imaginaryPart);
        }

        public Complex multiply(Complex other) {
            double realPart = (this.real * other.real) - (this.imaginary * other.imaginary);
            double imaginaryPart = (this.real * other.imaginary) + (this.imaginary * other.real);
            return new Complex(realPart, imaginaryPart);
        }

        public Complex divide(Complex other) {
            double denominator = other.real * other.real + other.imaginary * other.imaginary;
            double realPart = (this.real * other.real + this.imaginary * other.imaginary) / denominator;
            double imaginaryPart = (this.imaginary * other.real - this.real * other.imaginary) / denominator;
            return new Complex(realPart, imaginaryPart);
        }

        public void display() {
            if (imaginary < 0) {
                System.out.println(real + " - " + Math.abs(imaginary) + "i");
            } else {
                System.out.println(real + " + " + imaginary + "i");
            }
        }
    }

    public static void main(String[] args) {
        Complex num1 = new Complex(3, 2);
        Complex num2 = new Complex(1, 7);

        System.out.print("num1: ");
        num1.display();

        System.out.print("num2: ");
        num2.display();

        Complex sum = num1.add(num2);
        System.out.print("sum: ");
        sum.display();

        Complex difference = num1.subtract(num2);
        System.out.print("difference: ");
        difference.display();

        Complex product = num1.multiply(num2);
        System.out.print("product: ");
        product.display();

        Complex quotient = num1.divide(num2);
        System.out.print("quotient: ");
        quotient.display();
    }
}
