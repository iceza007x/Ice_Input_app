import jlab.graphics.DWindow;
import java.util.Scanner;

public class NewtonMethod {
    
    // Function for which we want to find the root
    public static double f(double x) {
        // Example equation: f(x) = x^2 - 4
        return x * x - 4;
    }
    
    // Derivative of the function
    public static double fPrime(double x) {
        // Derivative of the equation: f'(x) = 2x
        return 2 * x;
    }

    // Newton's Method implementation
    public static double newtonMethod(double initialGuess, double tolerance, int maxIterations) {
        double x = initialGuess;
        int iteration = 0;

        while (iteration < maxIterations) {
            double fx = f(x);           // Value of the function at x
            double fxPrime = fPrime(x); // Value of the derivative at x

            // Calculate the new value of x using Newton's Method formula
            double xNew = x - fx / fxPrime;

            // If the difference between new x and old x is small enough, stop
            if (Math.abs(xNew - x) < tolerance) {
                return xNew;  // Return the root found
            }

            x = xNew;  // Update x for the next iteration
            iteration++;
        }

        // If root is not found within max iterations
        System.out.println("Root could not be found within " + maxIterations + " iterations");
        return x;
    }

    public static void main(String[] args) {
        double initialGuess = 1.0;  // Initial guess for the root
        double tolerance = 1e-6;    // Desired precision
        int maxIterations = 100;    // Maximum number of iterations

        double root = newtonMethod(initialGuess, tolerance, maxIterations);
        System.out.println("Root found: " + root);
    }
}
