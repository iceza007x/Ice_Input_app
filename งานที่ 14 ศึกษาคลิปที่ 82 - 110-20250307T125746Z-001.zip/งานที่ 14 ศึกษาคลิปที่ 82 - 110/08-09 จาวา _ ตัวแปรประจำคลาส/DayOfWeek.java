import jlab.graphics.DWindow;
import java.util.Scanner;

public class DayOfWeek {

    // Class variable to store the days of the week
    private static String[] daysOfWeek = {
        "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    };

    // Method to return the day of the week based on index
    public static String getDayOfWeek(int index) {
        if (index >= 0 && index < 7) {
            return daysOfWeek[index];
        } else {
            return "Invalid day index";  // In case index is out of bounds
        }
    }

    public static void main(String[] args) {
        // Using the class variable 'daysOfWeek' through the class name
        System.out.println("Day 1: " + DayOfWeek.getDayOfWeek(0));  // Sunday
        System.out.println("Day 2: " + DayOfWeek.getDayOfWeek(1));  // Monday
        System.out.println("Day 7: " + DayOfWeek.getDayOfWeek(6));  // Saturday
        System.out.println("Invalid Day: " + DayOfWeek.getDayOfWeek(7));  // Invalid index
    }
}
