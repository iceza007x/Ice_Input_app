import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.ArrayList;

public class MatchingGame {
    private JFrame frame;
    private JPanel panel;
    private JButton[] buttons;
    private ArrayList cardValues;
    private int firstCardIndex = -1;
    private int secondCardIndex = -1;
    private boolean[] revealedCards;
    private int matchedPairs = 0;  // Track matched pairs

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MatchingGame();
            }
        });
    }

    public MatchingGame() {
        // Set up the frame
        frame = new JFrame("Memory Matching Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Initialize the card values without generics
        cardValues = new ArrayList(); // Generic types are removed
        for (int i = 1; i <= 5; i++) {
            cardValues.add(new Integer(i)); // Add integer value without generics
            cardValues.add(new Integer(i)); // Add integer value again to make pairs
        }
        Collections.shuffle(cardValues);

        // Initialize revealed cards
        revealedCards = new boolean[cardValues.size()];

        // Set up the panel and buttons
        panel = new JPanel();
        panel.setLayout(new GridLayout(2, 5)); // 2 rows, 5 columns
        buttons = new JButton[cardValues.size()];

        for (int i = 0; i < cardValues.size(); i++) {
            buttons[i] = new JButton("*");
            buttons[i].setFont(new Font("Arial", Font.PLAIN, 36));
            buttons[i].setFocusPainted(false);

            // Set random colors for each button
            setRandomColor(buttons[i]);

            final int index = i; // Use final for lambda expression
            buttons[i].addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    handleCardClick(index);
                }
            });
            panel.add(buttons[i]);
        }

        frame.add(panel, BorderLayout.CENTER);
        frame.pack();
        frame.setVisible(true);
    }

    private void handleCardClick(int index) {
        if (revealedCards[index]) {
            return; // If card is already revealed, do nothing
        }

        // Reveal the card
        buttons[index].setText(String.valueOf(cardValues.get(index))); // Cast automatically to Integer
        revealedCards[index] = true;

        // Check if it's the first or second card clicked
        if (firstCardIndex == -1) {
            firstCardIndex = index;
        } else {
            secondCardIndex = index;

            // Check if the two cards match
            if (cardValues.get(firstCardIndex).equals(cardValues.get(secondCardIndex))) {
                // If they match, leave them revealed
                matchedPairs++;
                resetIndices();
                
                // Check if all pairs are matched
                if (matchedPairs == cardValues.size() / 2) {
                    // If all pairs are matched, show a message and stop the game
                    JOptionPane.showMessageDialog(frame, "You won! All pairs matched!");
                    System.exit(0); // Exit the game
                }
            } else {
                // If they don't match, hide them after a short delay
                Timer timer = new Timer(500, new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        buttons[firstCardIndex].setText("*");
                        buttons[secondCardIndex].setText("*");
                        revealedCards[firstCardIndex] = false;
                        revealedCards[secondCardIndex] = false;
                        resetIndices();
                    }
                });
                timer.setRepeats(false);
                timer.start();
            }
        }
    }

    private void resetIndices() {
        firstCardIndex = -1;
        secondCardIndex = -1;
    }

    // Randomly set button colors to make them visually different
    private void setRandomColor(JButton button) {
        Color[] colors = {
            Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA,
            Color.ORANGE, Color.PINK, Color.LIGHT_GRAY, Color.GRAY
        };
        int randomIndex = (int) (Math.random() * colors.length);
        button.setBackground(colors[randomIndex]);
    }
}
